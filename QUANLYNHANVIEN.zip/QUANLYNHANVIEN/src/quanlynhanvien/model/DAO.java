package quanlynhanvien.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DAO {

    public static final String HOSTNAME = "localhost";
    public static final String PORT = "1433";
    public static final String DBNAME = "Quanlynhanvien";
    public static final String USERNAME = "sa";
    public static final String PASSWORD = "123456";

    public static Connection getConnection() {

        String connectionUrl = "jdbc:sqlserver://" + HOSTNAME + ":" + PORT + ";"
                + "databaseName=" + DBNAME;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            return DriverManager.getConnection(connectionUrl, USERNAME, PASSWORD);
        } // Handle any errors that may have occurred.
        catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(System.out);
        }
        return null;
    }

    //doc du lieu
    public static List loadData() {
        List<NhanVien> listNhanvien = new ArrayList<>();
        try {
            String sql = "Select * from Nhanvien";
            Connection con = DAO.getConnection();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {
                String ma = rs.getString(1);
                String ten = rs.getString(2);
                String gioitinh = rs.getString(3);
                int tuoi = rs.getInt(4);
                int luong = rs.getInt(5);
                String email = rs.getString(6);
                String phone = rs.getString(7);
                NhanVien nv = new NhanVien(ma, ten, gioitinh, tuoi, luong, email, phone);
                listNhanvien.add(nv);
            }
            con.close();

        } catch (Exception e) {
        }
        return listNhanvien;
    }

}
